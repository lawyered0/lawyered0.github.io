---
name: practice-contract-redline
description: Apply established edits as genuine Word tracked changes, verify marked and clean DOCX outputs, and save internal artifacts. Use only when substantive positions are already decided.
---

# Contract Redline

This skill applies established changes; it does not decide negotiation or legal
positions. Require an editable `.docx`. Do not reconstruct a contract from PDF.
Read `${LAWYEREDOS_ROOT}/docs/workflows/redline-meaning.md` for the operative
meaning and final-artifact checks. If substantive positions are not established,
use the contract-review source module selected from
`${LAWYEREDOS_ROOT}/docs/WORKFLOW-CATALOG.md` before returning to this skill.
Hash the exact source before generation and confirm it is unchanged after all
outputs are produced. Existing revisions are a separate source state; do not
silently edit through or accept another reviewer's changes.

The pinned MIT engine is under
`${LAWYEREDOS_ROOT}/vendor/legal-redline-tools`. Preserve its `LICENSE` and
attribution. Run it on `PYTHONPATH`; do not install another copy implicitly.

```bash
PKG="${LAWYEREDOS_ROOT}/vendor/legal-redline-tools"
PYTHONPATH="$PKG" "${LAWYEREDOS_PYTHON:-python3}" -m legal_redline.cli apply \
  source.docx redlined.docx --author "<configured author>" \
  --from-json redlines.json
```

Use exact, unique text spans. The change-set JSON remains scratch material and
must not contain internal rationale in a counterparty artifact. A failed or
partial apply is not repaired by hand-editing OOXML. A source containing any
pre-existing revision or comment markup is a distinct review state: stop and
have the user choose an authoritative clean source or separately resolve the
existing review. The engine refuses existing, duplicate, symlinked, or
source-colliding output paths and stages all requested outputs before publishing.
Input snapshots are bounded at 100 MiB compressed, 50 MiB per package entry,
and 200 MiB total uncompressed. Oversized, duplicate-member, unsafe-path,
truncated, or non-DOCX packages fail without output.

Keep counterparty-facing marked/clean files separate from internal rationale,
walkaway positions, or privileged notes. Generate and persist only the outputs
the user requested. A Word comment or unresolved revision makes a
counterparty-facing artifact not ready unless the user expressly decides to
retain it after review.

Verification requires:

1. Exit zero and `Applied: N/N`.
2. Structural `w:ins`/`w:del` counts and configured revision author.
3. Accepted text comparison against the intended change set.
4. Full-page render of marked and clean DOCX files.
5. Placeholder, comment, metadata, party, signature, and concession checks.
6. Claude-only adversarial review when the outbound risk warrants it.

Apply the redline-meaning contract to the marked text and intended accepted
text. Mechanical application and revision counts do not prove the negotiated
effect. Separate unresolved choices from approved edits; do not generate a
single operative clause containing incompatible alternatives. Recheck any
material revision against its source and approved position.

Generate a clean copy and verify it separately:

```bash
"${LAWYEREDOS_PYTHON:-python3}" "${LAWYEREDOS_ROOT}/scripts/accept_tracked_changes.py" \
  redlined.docx --output clean.docx
"${LAWYEREDOS_PYTHON:-python3}" "${LAWYEREDOS_ROOT}/scripts/render_docx.py" clean.docx \
  --output-dir "<empty clean render directory>"
```

The clean-copy helper accepts insertion/deletion/move wrappers, removes the
track-revisions setting, validates the entire Word XML package, and fails
without output if comments, unsupported property revisions, or any residual
revision/tracking marker remain. It also fails closed when a removed revision
contains relationship-backed or package content (such as an image, object,
hyperlink, footnote/endnote reference, or external chunk), because hiding the
visible revision would not safely remove the related package bytes.

Persist only requested, verified, versioned outputs with the
guarded writer. On a collision or stale preview, inspect the current target and
preview again; never overwrite newer work or bypass a protected-path or symlink
refusal. Never send or negotiate.

For source, date, authority, and handoff limits, read
`${LAWYEREDOS_ROOT}/docs/workflows/source-verification.md`,
`${LAWYEREDOS_ROOT}/docs/workflows/dates.md`, and
`${LAWYEREDOS_ROOT}/docs/workflows/records-and-handoffs.md` as relevant. Do not
create an unrequested clean copy or rationale artifact merely for delivery;
verification artifacts remain private scratch unless their save is approved.

Read [`references/change-set.md`](references/change-set.md) before building a
change list.
